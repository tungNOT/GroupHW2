package com.example.grouphw2_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javaapplication1.Account;

public class AccountSubOptionActivity extends AppCompatActivity {
    Account acc;
    List<Account> accList;
    Button contactButton;
    int accPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_sub_option);

        Intent intent = getIntent();
        accPosition = getIntent().getExtras().getInt("accPosition");
        accList = (List<Account>) intent.getSerializableExtra("accountList");

        contactButton = (Button) findViewById(R.id.contactButton);
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openContactActivity();
            }
        });

    }
    public void openContactActivity(){
        Intent intent = new Intent(this, ContactOptionActivity.class);
        intent.putExtra("accPosition",(int) accPosition);
        intent.putExtra("accountList", (Serializable) accList);
        startActivityForResult(intent,4);
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4) {
            if(resultCode == RESULT_OK) {
                accList = (List<Account>) data.getSerializableExtra("accList");
                Intent intent = new Intent(this,AccountSubOptionActivity.class);
                intent.putExtra("accList",(Serializable) accList);
                setResult(RESULT_OK,intent);
                finish();

            }
        }
    }
}
