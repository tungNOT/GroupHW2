package com.example.grouphw2_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;
import java.util.List;

import javaapplication1.Account;

public class AccountSubOptionActivity extends AppCompatActivity {
    Account acc;
    List<Account> accList;
    Button contactButton;
    int accPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_sub_option);

        Intent intent = getIntent();
        accPosition = getIntent().getExtras().getInt("accPosition");
        accList = (List<Account>) intent.getSerializableExtra("accountList");

        contactButton = (Button) findViewById(R.id.contactButton);
        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openContactActivity();
            }
        });

    }
    public void openContactActivity(){
        Intent intent = new Intent(this, ContactOptionActivity.class);
        intent.putExtra("accPosition",(int) accPosition);
        intent.putExtra("accountList", (Serializable) accList);
        startActivity(intent);
    }
}
