package com.example.grouphw2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import javaapplication1.Account;
import javaapplication1.Contact;

public class ContactRecyclerViewAdapter extends RecyclerView.Adapter<ContactRecyclerViewAdapter.ViewHolder> {
    //private final List<DummyItem> mValues;
    //private final OnListFragmentInteractionListener mListener;
    //private final ReminderList reminderList;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;
    private Account acc;
    private Contact cont;

    private List<Contact> contactList;

    /*
    public ReminderListRecyclerViewAdapter(List<DummyItem> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }
    */
    // data is passed into the constructor
    public ContactRecyclerViewAdapter(Context context, List<Contact> cl) {
        this.mInflater = LayoutInflater.from(context);
        this.contactList = cl;
   }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_row, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String con = contactList.get(position).getName();
        String con1 = contactList.get(position).getPhone();
        String con2 = contactList.get(position).getEmail();

        holder.myTextView.setText("Name: ");
        holder.myTextView.append(con);
        holder.myTextView.append("| Phone: ");
        holder.myTextView.append(con1);
        holder.myTextView.append("| Email: ");
        holder.myTextView.append(con2);
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return contactList.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView myTextView;

        ViewHolder(View itemView) {
            super(itemView);
            myTextView = itemView.findViewById(R.id.tvAnimalName);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    // convenience method for getting data at click position
    String getItem(int id) {
        return contactList.get(id).getName();
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}
