package com.example.grouphw2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

import javaapplication1.Account;
import javaapplication1.Contact;

public class DisplayContact extends AppCompatActivity implements ContactRecyclerViewAdapter.ItemClickListener  {
    Account acc;
    List<Contact> contactList;
    ContactRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        contactList = (List<Contact>) intent.getSerializableExtra(MainActivity.EXTRA_LIST);

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvReminderList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ContactRecyclerViewAdapter(this, contactList);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(View view, int position) {

    }
}
