package com.example.grouphw2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.grouphw2.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javaapplication1.Account;


public class MainActivity extends AppCompatActivity implements AccountRecyclerViewAdapter.ItemClickListener {
    public static final String EXTRA_LIST = "edu.csueastbay.cs.reminders.LIST";
    AccountRecyclerViewAdapter adapter;
    Account acc;
    Account acc2;
    List<Account> acclist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // data to populate the RecyclerView with


        acclist = new ArrayList<>();

        acc = new Account("Tung Account", "tech", "Hayward", "CA", "510-543-4354","Tung Nguyen" );
        acc.newContact("abc","employee","510-323-3249","abc@gmmail.com");
        acc.newContact("bcd","employee","510-323-3248","bcd@gmmail.com");
        acc.newContact("cde","employee","510-323-3247","cde@gmmail.com");

        acc2 = new Account("Vinh Account", "CS", "Hayward", "CA", "510-600-9094","Vinh Trang" );
        acc2.newContact("def","employee","510-323-7251","def@gmmail.com");
        acc2.newContact("efg","employee","510-323-5851","efg@gmmail.com");
        acc2.newContact("fgh","employee","510-323-5291","fgh@gmmail.com");


        acclist.add(acc);
        acclist.add(acc2);

        // acc = new Account("Vinh Account", "IT", "Hayward", "CA", "510-600-9094","Vinh Trang" );
        // acc.newContact("vinh","employee","510-323-3249","vihgn@gmmail.com");

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvAnimals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AccountRecyclerViewAdapter(this, acclist);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }


    @Override
    public void onItemClick(View view, int position) {
        //Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, DisplayContact.class);
        //EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_LIST, (Serializable) acclist.get(position).getContactLst());
        startActivity(intent);
    }

}