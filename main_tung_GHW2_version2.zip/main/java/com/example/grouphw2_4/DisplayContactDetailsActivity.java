package com.example.grouphw2_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

import javaapplication1.Account;
import javaapplication1.Contact;

public class DisplayContactDetailsActivity extends AppCompatActivity {
    List<Contact> contactList;
    int contactPosition;
    TextView name, title,phone,email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_contact_details);

        Intent intent = getIntent();
        contactList = (List<Contact>) intent.getSerializableExtra("contactList");
        contactPosition = getIntent().getExtras().getInt("contactPosition");

        name = (TextView) findViewById(R.id.tvContactName);
        title = (TextView) findViewById(R.id.tvContactTitle);
        phone = (TextView) findViewById(R.id.tvContactPhone);
        email = (TextView) findViewById(R.id.tvContactEmail);

        name.setText(contactList.get(contactPosition).getName());
        title.setText(contactList.get(contactPosition).getTitle());
        phone.setText(contactList.get(contactPosition).getPhone());
        email.setText(contactList.get(contactPosition).getEmail());
    }
}
